from django.apps import AppConfig


class TinylinkConfig(AppConfig):
    name = 'tinylink'
