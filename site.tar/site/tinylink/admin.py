from django.contrib import admin
from tinylink.models import Link

admin.site.register(Link)